﻿using Microsoft.AspNetCore.Mvc;
using services;

namespace controller_7.Controllers
{
    [ApiController]
    [Route("api/controller")]
    public class ServicesController:ControllerBase
    {
        IOperationTransient transient;
        IOperationSingleton singleton;
        IOperationScoped scoped;
        public ServicesController(IOperationTransient transient, IOperationSingleton singleton, IOperationScoped scoped)
        {
            this.transient = transient;
            this.singleton = singleton;
            this.scoped = scoped;
        }
        [HttpGet]
        public List<string> GetAll()
        {
            ICheck i;
            i.CheckLifetime();

            List<string> guides = new List<string>() { 
                $"In Controller transient: {transient.OperationId.ToString()}",
                $"In Controller singleton: {singleton.OperationId.ToString()}",
                $"In Controller scoped: {scoped.OperationId.ToString()}"
            };
            //return c.CheckLifetime().Concat(guides).ToList();
            return guides;
            //return c.CheckLifetime();
        }
    }
}
