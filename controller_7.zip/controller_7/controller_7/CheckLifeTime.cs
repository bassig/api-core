﻿using services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace controller_7
{
    public class CheckLifeTime : ICheck
    {
         IOperationTransient transient;
         IOperationSingleton singleton;
         IOperationScoped scoped;
        public CheckLifeTime( IOperationTransient transient, IOperationSingleton singleton, IOperationScoped scoped)
        {
            this.transient = transient;
            this.singleton = singleton;
            this.scoped = scoped;
        }
        public List<string> CheckLifetime()
        {
            List<string> list = new List<string>();
            list.Add($"In Service transient: {transient.OperationId.ToString()}");
            list.Add($"In Service singleton: {singleton.OperationId.ToString()}");
            list.Add($"In Service scoped: {scoped.OperationId.ToString()}");
            return list;
        }
    }
}
